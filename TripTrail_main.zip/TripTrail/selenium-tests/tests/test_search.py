import pytest

from pages.results_page import ResultsPage
from pages.search_page import SearchPage
from tests.helpers import DATA, ROUTE, to_results


@pytest.mark.smoke
def test_tc01_search_seeded_route_returns_expected_itineraries(driver, base_url):
    results = to_results(driver, base_url)
    assert sorted(results.card_ids()) == sorted(ROUTE["expected_ids"])
    assert results.text(results.COUNT).startswith(str(len(ROUTE["expected_ids"])))


@pytest.mark.parametrize("route", DATA["other_routes"], ids=lambda r: f'{r["origin"]}-{r["destination"]}')
def test_tc01_data_driven_other_routes(driver, base_url, route):
    results = to_results(driver, base_url, route)
    assert len(results.cards()) == route["expected_count"]


@pytest.mark.negative
def test_search_with_unseeded_route_shows_empty_state(driver, base_url):
    route = DATA["no_result_route"]
    SearchPage(driver).open(base_url).search(route["origin"], route["destination"], route["date"])
    results = ResultsPage(driver).wait_loaded()
    assert results.visible(results.NO_RESULTS).is_displayed()
    assert results.cards() == []


@pytest.mark.negative
@pytest.mark.parametrize(
    "origin,destination,date,message",
    [
        ("Hyderabad", "Hyderabad", "2030-01-15", "must be different"),
        ("Hyderabad", "Chennai", "15/01/2030", "YYYY-MM-DD"),
        ("Hyderabad", "Chennai", "2001-01-01", "past"),
        ("", "Chennai", "2030-01-15", "origin"),
    ],
)
def test_search_validation_errors(driver, base_url, origin, destination, date, message):
    page = SearchPage(driver).open(base_url)
    page.search(origin, destination, date)
    assert message in page.error_text()
    assert driver.find_elements(*page.SEARCH_BTN)  # still on the search page
