import pytest

from pages.review_page import ReviewPage
from tests.helpers import ROUTE, to_seats


def test_tc06_selected_seat_appears_in_reservation_summary(driver, base_url):
    seats = to_seats(driver, base_url, "TT102")
    assert not seats.next_enabled()                  # disabled until a seat is picked
    seats.choose("2A")
    assert seats.status("2A") == "selected"
    seats.go_next()
    review = ReviewPage(driver).wait_loaded()
    assert review.field("seat") == "2A"
    assert review.field("route") == f'{ROUTE["origin"]} → {ROUTE["destination"]}'
    assert review.field("date") == ROUTE["date"]
    assert review.field("fare") == "₹3,250"


@pytest.mark.negative
def test_unavailable_seat_cannot_be_selected(driver, base_url):
    seats = to_seats(driver, base_url)
    assert seats.status("1B") == "unavailable"
    assert not seats.seat("1B").is_enabled()
    assert not seats.next_enabled()


def test_changing_seat_moves_the_selection(driver, base_url):
    seats = to_seats(driver, base_url)
    seats.choose("1A")
    seats.choose("1C")
    assert seats.status("1A") == "available"
    assert seats.status("1C") == "selected"
