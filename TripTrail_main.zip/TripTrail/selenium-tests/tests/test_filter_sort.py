import pytest

from tests.helpers import DATA, to_results


@pytest.mark.parametrize("limit", DATA["price_limits"])
def test_tc02_price_filter_limits_visible_results(driver, base_url, limit):
    results = to_results(driver, base_url)
    total = len(results.cards())
    results.filter_by_max_price(str(limit))
    prices = results.prices()
    assert prices, "filter should leave at least one itinerary"
    assert all(p <= limit for p in prices)          # every visible card obeys the limit
    if limit < 6000:
        assert len(prices) < total                   # and the list really changed


@pytest.mark.parametrize("order", ["asc", "desc"])
def test_tc03_sort_by_departure(driver, base_url, order):
    results = to_results(driver, base_url)
    results.sort_by_departure(order)
    times = results.departures()                     # parse ALL cards, not just first/last
    assert times == sorted(times, reverse=(order == "desc"))
