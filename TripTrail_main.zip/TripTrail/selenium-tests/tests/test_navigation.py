from pages.results_page import ResultsPage
from pages.search_page import SearchPage
from tests.helpers import ROUTE, to_results


def test_browser_back_and_forward_keep_the_workflow_state(driver, base_url):
    results = to_results(driver, base_url)
    results.select("TT102")
    from pages.passenger_page import PassengerPage
    passenger = PassengerPage(driver)
    passenger.visible(passenger.BANNER)

    driver.back()                                    # -> results
    results = ResultsPage(driver).wait_loaded()
    assert len(results.cards()) == len(ROUTE["expected_ids"])

    driver.forward()                                 # -> passenger, itinerary still selected
    passenger.visible(passenger.BANNER)
    assert passenger.summary()["fare"] == "₹3,250"


def test_help_link_opens_in_a_new_tab(driver, base_url):
    page = SearchPage(driver).open(base_url)
    original = driver.current_window_handle
    title = page.open_help_in_new_tab()
    assert "Help" in title
    driver.close()
    driver.switch_to.window(original)
    assert driver.find_elements(*page.SEARCH_BTN)
