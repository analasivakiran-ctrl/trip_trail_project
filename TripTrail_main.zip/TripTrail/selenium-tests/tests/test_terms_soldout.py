import pytest

from tests.helpers import to_passenger, to_results


def test_tc07_accepting_terms_in_iframe_enables_next(driver, base_url):
    page = to_passenger(driver, base_url)
    assert not page.next_enabled()                   # disabled before accepting
    page.accept_terms()
    assert page.terms_accepted()
    assert page.next_enabled()


@pytest.mark.negative
def test_tc08_sold_out_itinerary_cannot_be_selected(driver, base_url):
    results = to_results(driver, base_url)
    assert results.availability_text("TT103") == "Sold out"
    assert not results.select_button_enabled("TT103")
    # availability is clear on a normal itinerary too
    assert "seats left" in results.availability_text("TT102")
    assert results.select_button_enabled("TT102")
