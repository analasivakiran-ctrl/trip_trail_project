"""Small flow helpers so each test can set up its own state (no reliance on test order)."""
from pages.passenger_page import PassengerPage
from pages.results_page import ResultsPage
from pages.search_page import SearchPage
from pages.seat_page import SeatPage
from utilities.data_reader import read_json

DATA = read_json("search_data.json")
ROUTE = DATA["seeded_route"]


def to_results(driver, base_url, route=ROUTE) -> ResultsPage:
    SearchPage(driver).open(base_url).search(route["origin"], route["destination"], route["date"])
    return ResultsPage(driver).wait_loaded()


def to_passenger(driver, base_url, itinerary_id="TT102") -> PassengerPage:
    to_results(driver, base_url).select(itinerary_id)
    page = PassengerPage(driver)
    page.visible(page.BANNER)
    return page


def to_seats(driver, base_url, itinerary_id="TT102") -> SeatPage:
    page = to_passenger(driver, base_url, itinerary_id)
    page.fill("Asha", "Rao", "asha.rao@example.test", "Indian")
    page.accept_terms()
    page.submit()
    return SeatPage(driver).wait_loaded()
