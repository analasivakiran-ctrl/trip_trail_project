import pytest

from tests.helpers import ROUTE, to_passenger
from utilities.data_reader import read_csv


def test_tc04_selected_itinerary_details_shown_on_passenger_page(driver, base_url):
    page = to_passenger(driver, base_url, "TT102")
    summary = page.summary()
    assert summary["route"] == f'{ROUTE["origin"]} → {ROUTE["destination"]}'
    assert summary["date"] == ROUTE["date"]
    assert summary["fare"] == "₹3,250"


@pytest.mark.negative
def test_tc05_missing_surname_blocks_workflow(driver, base_url):
    page = to_passenger(driver, base_url)
    page.fill("Asha", "", "asha.rao@example.test", "Indian")
    page.accept_terms()                              # Next is only enabled after terms (TC07)
    page.submit()
    assert "required" in page.surname_error()
    assert driver.find_elements(*page.NEXT), "must still be on the passenger page"
    assert not driver.find_elements(*page.tid("seat-section"))


@pytest.mark.negative
def test_invalid_email_is_rejected(driver, base_url):
    page = to_passenger(driver, base_url)
    page.fill("Asha", "Rao", "not-an-email", "Indian")
    page.accept_terms()
    page.submit()
    assert "valid" in page.text(page.tid("error-email"))


@pytest.mark.parametrize("row", read_csv("passengers.csv"), ids=lambda r: r["first_name"])
def test_full_workflow_data_driven(driver, base_url, row):
    """CSV-driven end-to-end run: search -> select -> passenger -> seat -> review."""
    from pages.review_page import ReviewPage
    from pages.seat_page import SeatPage

    page = to_passenger(driver, base_url, "TT104")
    page.fill(row["first_name"], row["surname"], row["email"], row["nationality"])
    page.accept_terms()
    page.submit()
    seats = SeatPage(driver).wait_loaded()
    seats.choose("3C")
    seats.go_next()
    review = ReviewPage(driver).wait_loaded()
    assert review.field("passenger") == f'{row["first_name"]} {row["surname"]}'
    assert review.field("seat") == "3C"
    assert review.field("fare") == "₹2,750"
    assert "nothing purchased" in review.field("status")
