"""unittest comparison (handout 6.1): class-level setUpClass / tearDownClass + assertions.

Run with:  python -m unittest tests.test_unittest_example -v
(pytest also collects it.)  Difference vs pytest: shared browser for the whole class via
setUpClass, assertions are self.assertXxx instead of plain `assert`, and no fixture injection.
"""
import unittest

from selenium import webdriver

from pages.search_page import SearchPage
from pages.results_page import ResultsPage
from utilities import config_reader
from utilities.data_reader import read_json


class TripTrailUnittestSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.set_window_size(1280, 900)
        cls.route = read_json("search_data.json")["seeded_route"]

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    def test_search_returns_six_cards(self):
        SearchPage(self.driver).open(config_reader.get_base_url()).search(
            self.route["origin"], self.route["destination"], self.route["date"])
        results = ResultsPage(self.driver).wait_loaded()
        self.assertEqual(len(results.cards()), 6)


if __name__ == "__main__":
    unittest.main()
