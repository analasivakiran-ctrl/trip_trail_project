"""BasePage: reusable Selenium helpers (explicit waits, click/type, tabs, frames, screenshots)."""
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from utilities.config_reader import get_timeout
from utilities.logger import get_logger
from utilities.screenshot import save_screenshot


class BasePage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, get_timeout())
        self.log = get_logger()

    # ---- locators ----------------------------------------------------------
    @staticmethod
    def tid(test_id: str):
        """Locator for the app's stable data-testid attribute."""
        return (By.CSS_SELECTOR, f'[data-testid="{test_id}"]')

    # ---- waits -------------------------------------------------------------
    def visible(self, locator):
        return self.wait.until(EC.visibility_of_element_located(locator))

    def all_visible(self, locator):
        return self.wait.until(EC.visibility_of_all_elements_located(locator))

    def clickable(self, locator):
        return self.wait.until(EC.element_to_be_clickable(locator))

    def gone(self, locator):
        return self.wait.until(EC.invisibility_of_element_located(locator))

    def present_all(self, locator):
        return self.driver.find_elements(*locator)

    # ---- actions -----------------------------------------------------------
    def click(self, locator):
        self.log.info("click %s", locator)
        self.clickable(locator).click()

    def type(self, locator, text: str):
        el = self.visible(locator)
        el.clear()
        el.send_keys(text)

    def select_by_value(self, locator, value: str):
        Select(self.visible(locator)).select_by_value(value)

    def select_by_text(self, locator, text: str):
        Select(self.visible(locator)).select_by_visible_text(text)

    def text(self, locator) -> str:
        return self.visible(locator).text.strip()

    def attr(self, locator, name: str):
        return self.visible(locator).get_attribute(name)

    def is_enabled(self, locator) -> bool:
        return self.visible(locator).is_enabled()

    # ---- frames and tabs ---------------------------------------------------
    def enter_frame(self, locator):
        self.wait.until(EC.frame_to_be_available_and_switch_to_it(locator))

    def leave_frame(self):
        self.driver.switch_to.default_content()

    def switch_to_new_tab(self, previous_handles):
        self.wait.until(lambda d: len(d.window_handles) > len(previous_handles))
        new = [h for h in self.driver.window_handles if h not in previous_handles][0]
        self.driver.switch_to.window(new)

    def screenshot(self, name: str):
        return save_screenshot(self.driver, name)
