from selenium.webdriver.common.by import By

from pages.base_page import BasePage


class PassengerPage(BasePage):
    BANNER = BasePage.tid("selected-itinerary-summary")
    ROUTE = BasePage.tid("summary-route")
    DATE = BasePage.tid("summary-date")
    FARE = BasePage.tid("summary-fare")
    FIRST = BasePage.tid("passenger-first-name")
    SURNAME = BasePage.tid("passenger-surname")
    EMAIL = BasePage.tid("passenger-email")
    NATIONALITY = BasePage.tid("passenger-nationality")
    ERR_SURNAME = BasePage.tid("error-surname")
    OPEN_TERMS = BasePage.tid("open-terms-button")
    TERMS_MODAL = BasePage.tid("terms-modal")
    TERMS_FRAME = BasePage.tid("terms-iframe")
    TERMS_STATUS = BasePage.tid("terms-status")
    NEXT = BasePage.tid("passenger-next")
    # elements INSIDE the iframe (plain ids, used only after switching into the frame)
    IN_CHECKBOX = (By.ID, "accept-terms")
    IN_BUTTON = (By.ID, "accept-button")

    def summary(self) -> dict:
        return {"route": self.text(self.ROUTE), "date": self.text(self.DATE), "fare": self.text(self.FARE)}

    def fill(self, first: str, surname: str, email: str, nationality: str):
        self.type(self.FIRST, first)
        self.type(self.SURNAME, surname)
        self.type(self.EMAIL, email)
        self.select_by_value(self.NATIONALITY, nationality)

    def accept_terms(self):
        self.click(self.OPEN_TERMS)
        self.visible(self.TERMS_MODAL)
        self.enter_frame(self.TERMS_FRAME)          # switch INTO the iframe
        self.click(self.IN_CHECKBOX)
        self.click(self.IN_BUTTON)
        self.leave_frame()                           # ALWAYS return to the main document
        self.gone(self.TERMS_MODAL)

    def terms_accepted(self) -> bool:
        return self.attr(self.TERMS_STATUS, "data-accepted") == "true"

    def next_enabled(self) -> bool:
        return self.is_enabled(self.NEXT)

    def submit(self):
        self.click(self.NEXT)

    def surname_error(self) -> str:
        return self.text(self.ERR_SURNAME)
