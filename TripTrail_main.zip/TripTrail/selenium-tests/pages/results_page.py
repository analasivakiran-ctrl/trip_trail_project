from selenium.webdriver.common.by import By

from pages.base_page import BasePage


class ResultsPage(BasePage):
    CARDS = BasePage.tid("itinerary-card")
    COUNT = BasePage.tid("results-count")
    NO_RESULTS = BasePage.tid("no-results")
    PRICE_FILTER = BasePage.tid("price-filter")
    SORT = BasePage.tid("departure-sort")
    SECTION = BasePage.tid("results-section")

    def wait_loaded(self):
        self.visible(self.SECTION)
        return self

    def cards(self):
        return self.present_all(self.CARDS)

    def card_ids(self):
        return [c.get_attribute("data-itinerary-id") for c in self.cards()]

    def prices(self):
        return [int(c.get_attribute("data-price")) for c in self.cards()]

    def departures(self):
        """Departure times as minutes after midnight (parsed from the displayed text)."""
        out = []
        for c in self.cards():
            hh, mm = c.find_element(By.CSS_SELECTOR, '[data-testid="departure-time"]').text.split(":")
            out.append(int(hh) * 60 + int(mm))
        return out

    def filter_by_max_price(self, value: str):
        self.select_by_value(self.PRICE_FILTER, value)
        # explicit wait on the real end state: every visible card obeys the limit
        self.wait.until(lambda d: all(p <= int(value) for p in self.prices()))

    def sort_by_departure(self, value: str):
        self.select_by_value(self.SORT, value)
        # explicit wait on the real end state: the list is ordered as requested
        def ordered(_):
            t = self.departures()
            return len(t) > 0 and t == sorted(t, reverse=(value == "desc"))
        self.wait.until(ordered)

    def card_by_id(self, itinerary_id: str):
        return self.visible((By.CSS_SELECTOR, f'[data-testid="itinerary-card"][data-itinerary-id="{itinerary_id}"]'))

    def select(self, itinerary_id: str):
        self.card_by_id(itinerary_id).find_element(By.CSS_SELECTOR, '[data-testid="select-itinerary"]').click()

    def select_button_enabled(self, itinerary_id: str) -> bool:
        card = self.card_by_id(itinerary_id)
        return card.find_element(By.CSS_SELECTOR, '[data-testid="select-itinerary"]').is_enabled()

    def availability_text(self, itinerary_id: str) -> str:
        return self.card_by_id(itinerary_id).find_element(By.CSS_SELECTOR, '[data-testid="availability-text"]').text
