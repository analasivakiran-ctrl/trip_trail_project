from pages.base_page import BasePage


class SearchPage(BasePage):
    ORIGIN = BasePage.tid("origin-input")
    DESTINATION = BasePage.tid("destination-input")
    DATE = BasePage.tid("travel-date-input")
    SEARCH_BTN = BasePage.tid("search-button")
    ERROR = BasePage.tid("search-error")
    HELP_LINK = BasePage.tid("help-link")

    def open(self, url: str):
        self.driver.get(url)
        self.visible(self.SEARCH_BTN)
        return self

    def search(self, origin: str, destination: str, date: str):
        if origin:
            self.select_by_value(self.ORIGIN, origin)
        if destination:
            self.select_by_value(self.DESTINATION, destination)
        self.type(self.DATE, date)
        self.click(self.SEARCH_BTN)

    def error_text(self) -> str:
        return self.text(self.ERROR)

    def open_help_in_new_tab(self) -> str:
        handles = list(self.driver.window_handles)
        self.click(self.HELP_LINK)
        self.switch_to_new_tab(handles)
        return self.driver.title
