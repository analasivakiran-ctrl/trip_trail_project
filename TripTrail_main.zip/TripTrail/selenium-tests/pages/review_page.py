from pages.base_page import BasePage


class ReviewPage(BasePage):
    ROOT = BasePage.tid("reservation-review")

    def wait_loaded(self):
        self.visible(self.ROOT)
        return self

    def field(self, name: str) -> str:
        return self.text(BasePage.tid(f"review-{name}"))
