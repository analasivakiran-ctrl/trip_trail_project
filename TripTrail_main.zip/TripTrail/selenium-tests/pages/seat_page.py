from selenium.webdriver.common.by import By

from pages.base_page import BasePage


class SeatPage(BasePage):
    SECTION = BasePage.tid("seat-section")
    SELECTED_LABEL = BasePage.tid("seat-selected-label")
    NEXT = BasePage.tid("seats-next")

    def wait_loaded(self):
        self.visible(self.SECTION)
        return self

    def seat(self, seat_id: str):
        return self.visible((By.CSS_SELECTOR, f'[data-testid="seat-option"][data-seat="{seat_id}"]'))

    def choose(self, seat_id: str):
        self.seat(seat_id).click()
        self.wait.until(lambda d: self.seat(seat_id).get_attribute("data-status") == "selected")

    def status(self, seat_id: str) -> str:
        return self.seat(seat_id).get_attribute("data-status")

    def next_enabled(self) -> bool:
        return self.is_enabled(self.NEXT)

    def go_next(self):
        self.click(self.NEXT)
