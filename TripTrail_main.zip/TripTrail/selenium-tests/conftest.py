"""Shared fixtures + failure hook (screenshot saved to reports/screenshots and embedded in the HTML report)."""
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions

from utilities import config_reader
from utilities.screenshot import save_screenshot


def pytest_addoption(parser):
    parser.addoption("--browser", action="store", default=None, help="chrome | edge | firefox")
    parser.addoption("--base-url", action="store", default=None, help="override base_url from config.ini")


@pytest.fixture(scope="session")
def base_url(request):
    return request.config.getoption("--base-url") or config_reader.get_base_url()


@pytest.fixture
def driver(request):
    """A fresh browser per test -> tests are independent of each other and of execution order."""
    name = (request.config.getoption("--browser") or config_reader.get_browser()).lower()
    headless = config_reader.is_headless()
    if name == "chrome":
        opts = ChromeOptions()
        if headless:
            opts.add_argument("--headless=new")
        drv = webdriver.Chrome(options=opts)
    elif name == "edge":
        opts = EdgeOptions()
        if headless:
            opts.add_argument("--headless=new")
        drv = webdriver.Edge(options=opts)
    elif name == "firefox":
        opts = FirefoxOptions()
        if headless:
            opts.add_argument("-headless")
        drv = webdriver.Firefox(options=opts)
    else:
        raise ValueError(f"Unsupported browser: {name}")
    drv.set_window_size(1280, 900)
    request.node.driver = drv
    yield drv
    drv.quit()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    drv = getattr(item, "driver", None)
    if report.when == "call" and report.failed and drv is not None:
        path = save_screenshot(drv, item.name.replace("/", "_").replace("[", "_").replace("]", ""))
        try:
            from pytest_html import extras
            report.extras = getattr(report, "extras", []) + [extras.png(drv.get_screenshot_as_base64())]
        except Exception:  # report plugin missing -> screenshot file is still saved
            pass
        print(f"Failure screenshot: {path}")
