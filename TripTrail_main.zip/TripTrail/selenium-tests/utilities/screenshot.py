"""Screenshot helper used by the failure hook in conftest.py."""
from datetime import datetime
from pathlib import Path

SHOT_DIR = Path(__file__).resolve().parent.parent / "reports" / "screenshots"


def save_screenshot(driver, test_name: str) -> Path:
    SHOT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = SHOT_DIR / f"{test_name}_{stamp}.png"
    driver.save_screenshot(str(path))
    return path
