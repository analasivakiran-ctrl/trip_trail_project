"""Reads config/config.ini so URL, browser and timeout stay out of test logic."""
import configparser
from pathlib import Path

_CFG = Path(__file__).resolve().parent.parent / "config" / "config.ini"


def _load() -> configparser.ConfigParser:
    parser = configparser.ConfigParser()
    parser.read(_CFG)
    return parser


def get_base_url() -> str:
    return _load().get("app", "base_url")


def get_browser() -> str:
    return _load().get("browser", "name").lower()


def is_headless() -> bool:
    return _load().getboolean("browser", "headless")


def get_timeout() -> int:
    return _load().getint("timeouts", "explicit_wait")
