import logging
from pathlib import Path

LOG_FILE = Path(__file__).resolve().parent.parent / "reports" / "run.log"


def get_logger(name: str = "triptrail") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
