# TripTrail – Wipro Project 4 (Travel Search & Reservation)

Two separate projects in one folder:

| Folder | What it is |
|---|---|
| `triptrail-app/` | The fictional travel portal (React + TypeScript + Vite + Tailwind + Motion). It is the **test target**. |
| `selenium-tests/` | The **assignment deliverable**: Python 3 + Selenium 4 + pytest framework (POM, BasePage, utilities, CSV/JSON data, HTML report, failure screenshots). |

> The handout says no real purchase or payment occurs. The app stops at a **simulated reservation review**.

## 1. Run the app
```bash
cd triptrail-app
npm install
npm run dev          # http://localhost:5173
```
Open `http://localhost:5173/?testmode=1` for the Selenium-friendly mode (animations off).

## 2. Run the tests (second terminal, app must be running)
```bash
cd selenium-tests
python -m venv .venv && .venv\Scripts\activate      # Windows
pip install -r requirements.txt
pytest                                  # Chrome by default, report -> reports/report.html
pytest --browser edge                   # Edge
pytest -m smoke                         # only smoke tests
python -m unittest tests.test_unittest_example -v    # unittest comparison
```
Selenium 4's built-in Selenium Manager downloads the matching driver automatically (Chrome/Edge must be installed).
Settings (URL, browser, headless, timeout) live in `selenium-tests/config/config.ini`.

## 3. Handout scenario → test mapping
| ID | Test |
|---|---|
| TC01 | `test_search.py::test_tc01_*` |
| TC02 | `test_filter_sort.py::test_tc02_*` |
| TC03 | `test_filter_sort.py::test_tc03_*` |
| TC04 | `test_selection_passenger.py::test_tc04_*` |
| TC05 | `test_selection_passenger.py::test_tc05_*` |
| TC06 | `test_seat.py::test_tc06_*` |
| TC07 | `test_terms_soldout.py::test_tc07_*` |
| TC08 | `test_terms_soldout.py::test_tc08_*` |
| Back/forward, new tab | `test_navigation.py` |

## 4. Manual walkthrough
1. Search Hyderabad → Bengaluru, date `2030-01-15` → 6 cards.
2. Price filter "Up to ₹3,000" → only TT104 and TT106. Sort "Earliest first" → times ascend.
3. TT103 is **Sold out** and its button is disabled. Select TT102.
4. Passenger page shows route, date, fare. "Continue" is disabled.
5. Fill the form (leave surname empty) → *Read terms* → tick the checkbox **inside the iframe** → *Accept*. "Continue" enables; submit → "Surname is required." and you stay on the page.
6. Fill the surname → seats → pick e.g. `2A` (`1B` etc. are unavailable) → review table shows seat, fare, route, date.

## 5. Final selectors (`data-testid`)
**Search:** `origin-input`, `destination-input`, `travel-date-input` (text, `YYYY-MM-DD`), `search-button`, `search-error`, `help-link` (opens new tab)
**Results:** `results-section`, `results-count`, `price-filter`, `departure-sort`, `itinerary-card` (`data-itinerary-id`, `data-price`, `data-departure`, `data-available`), `departure-time`, `arrival-time`, `duration`, `price`, `availability-text`, `select-itinerary`, `no-results`, `back-button`
**Passenger:** `selected-itinerary-summary`, `summary-route`, `summary-date`, `summary-fare`, `passenger-first-name`, `passenger-surname`, `passenger-email`, `passenger-nationality`, `error-first-name|surname|email|nationality`, `open-terms-button`, `terms-modal`, `terms-iframe`, `terms-status` (`data-accepted`), `passenger-next`
**Inside the iframe (plain ids):** `#accept-terms`, `#accept-button`
**Seats:** `seat-section`, `seat-option` (`data-seat`, `data-status` = available|selected|unavailable), `seat-selected-label`, `seats-next`
**Review:** `reservation-review`, `review-route|date|times|passenger|email|seat|fare|status`, `new-search-button`

## 6. Test data (all fictional)
Seeded routes: Hyderabad→Bengaluru (TT101–TT106, TT103 sold out), Hyderabad→Chennai (TT201–TT205, TT202 sold out), Mumbai→Delhi (TT301–TT306, TT303 sold out). Unavailable seats: 1B 2C 3A 4D 5B 6C. Any other route shows the empty state.

## 7. Known limitations / still to do
* **Nothing in this folder has been built or run yet.** It was written in a sandbox without internet, so `npm install`, `npm run build`, TypeScript checks and the Selenium run are **untested**. Run steps 1–2 and fix any error you see.
* This is a **fresh** app (your original Bolt project/Supabase code was not uploaded). No database is used; data is local test data, which the handout allows.
* No photos (offline sandbox); cards use gradients/icons.
* Your submission also needs: a locator inventory table, one *difficult locator / synchronization choice / debugging issue* write-up, a Chrome **and** Edge run, the HTML report and at least one failure screenshot — these only come from your real runs.
* Animation tip: modal/page transitions are ~0.15 s fades; tests wait on real UI state, never `sleep`.
