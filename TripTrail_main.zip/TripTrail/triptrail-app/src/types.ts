export type Step = 'search' | 'results' | 'passenger' | 'seats' | 'review';

export interface SearchQuery { origin: string; destination: string; date: string }

export interface Itinerary {
  id: string;
  carrier: string;
  origin: string;
  destination: string;
  departure: string; // "HH:MM" 24h, zero padded
  arrival: string;   // "HH:MM"
  price: number;     // INR
  seatsLeft: number; // 0 = sold out
}

export interface Passenger { firstName: string; surname: string; email: string; nationality: string }
