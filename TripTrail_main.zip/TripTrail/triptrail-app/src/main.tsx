import React from 'react';
import ReactDOM from 'react-dom/client';
import { MotionConfig } from 'motion/react';
import App from './App';
import './index.css';

// ?testmode=1 disables animation so automated tests are fully deterministic.
const testMode = new URLSearchParams(window.location.search).get('testmode') === '1';
if (testMode) document.documentElement.classList.add('no-motion');

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {/* "user" respects the OS prefers-reduced-motion setting */}
    <MotionConfig reducedMotion={testMode ? 'always' : 'user'}>
      <App />
    </MotionConfig>
  </React.StrictMode>
);
