import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import Background from './components/Background';
import Header from './components/Header';
import Stepper from './components/Stepper';
import SearchForm from './components/SearchForm';
import ResultsList from './components/ResultsList';
import ItineraryBanner from './components/ItineraryBanner';
import PassengerForm from './components/PassengerForm';
import TermsModal from './components/TermsModal';
import SeatMap from './components/SeatMap';
import ReviewSummary from './components/ReviewSummary';
import type { Itinerary, Passenger, SearchQuery, Step } from './types';

const STEPS: Step[] = ['search', 'results', 'passenger', 'seats', 'review'];

export default function App() {
  const [step, setStep] = useState<Step>('search');
  const [query, setQuery] = useState<SearchQuery | null>(null);
  const [itinerary, setItinerary] = useState<Itinerary | null>(null);
  const [passenger, setPassenger] = useState<Passenger | null>(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [seat, setSeat] = useState<string | null>(null);
  const [termsOpen, setTermsOpen] = useState(false);

  const url = (s: Step) => `${window.location.pathname}${window.location.search}#/${s}`;

  // Each step gets its own history entry so the browser Back/Forward buttons work (handout 4.6).
  useEffect(() => {
    window.history.replaceState({ step: 'search' }, '', url('search'));
    const onPop = (e: PopStateEvent) => {
      const s = e.state?.step as Step | undefined;
      setStep(s && STEPS.includes(s) ? s : 'search');
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const go = (next: Step) => {
    window.history.pushState({ step: next }, '', url(next));
    setStep(next);
    window.scrollTo(0, 0);
  };

  // If the data a step needs is missing (e.g. page reloaded), fall back safely.
  const safeStep: Step =
    step === 'results' && !query ? 'search'
    : step === 'passenger' && !(query && itinerary) ? 'search'
    : step === 'seats' && !(query && itinerary && passenger) ? 'search'
    : step === 'review' && !(query && itinerary && passenger && seat) ? 'search'
    : step;

  const resetAll = () => {
    setQuery(null); setItinerary(null); setPassenger(null); setSeat(null); setTermsAccepted(false);
    go('search');
  };

  const acceptTerms = useCallback(() => { setTermsAccepted(true); setTermsOpen(false); }, []);
  const closeTerms = useCallback(() => setTermsOpen(false), []);

  return (
    <div className="relative min-h-screen">
      <Background />
      <div className="relative z-10">
        <Header />
        <main className="mx-auto max-w-5xl px-4 pb-16">
          <Stepper current={safeStep} />
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={safeStep}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              data-testid={`page-${safeStep}`}
            >
              {safeStep === 'search' && (
                <SearchForm
                  initial={query}
                  onSearch={(q) => {
                    setQuery(q); setItinerary(null); setPassenger(null); setSeat(null); setTermsAccepted(false);
                    go('results');
                  }}
                />
              )}
              {safeStep === 'results' && query && (
                <ResultsList query={query} onBack={() => window.history.back()}
                  onSelect={(i) => { setItinerary(i); setSeat(null); go('passenger'); }} />
              )}
              {safeStep === 'passenger' && query && itinerary && (
                <>
                  <ItineraryBanner itinerary={itinerary} query={query} />
                  <PassengerForm
                    initial={passenger} termsAccepted={termsAccepted}
                    onOpenTerms={() => setTermsOpen(true)}
                    onSubmit={(p) => { setPassenger(p); go('seats'); }}
                    onBack={() => window.history.back()}
                  />
                </>
              )}
              {safeStep === 'seats' && query && itinerary && passenger && (
                <>
                  <ItineraryBanner itinerary={itinerary} query={query} />
                  <SeatMap selected={seat} onSelect={setSeat} onNext={() => go('review')} onBack={() => window.history.back()} />
                </>
              )}
              {safeStep === 'review' && query && itinerary && passenger && seat && (
                <ReviewSummary itinerary={itinerary} query={query} passenger={passenger} seat={seat}
                  onBack={() => window.history.back()} onReset={resetAll} />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
        <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500">
          TripTrail · fictional demo for Selenium practice · no real bookings or payments
        </footer>
      </div>
      <TermsModal open={termsOpen} onClose={closeTerms} onAccept={acceptTerms} />
    </div>
  );
}
