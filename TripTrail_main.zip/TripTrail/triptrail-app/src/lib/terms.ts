// HTML shown inside the terms <iframe srcdoc>. The checkbox + button live INSIDE the iframe,
// so Selenium must switch_to.frame(...) to use them (handout scenario TC07).
export const TERMS_HTML = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Demo terms</title>
<style>
  body{font-family:system-ui,sans-serif;background:#19143a;color:#e5e7eb;padding:16px;font-size:14px}
  button{padding:8px 14px;border-radius:8px;border:0;background:#c9a227;color:#04201c;font-weight:600;cursor:pointer}
  button:disabled{opacity:.4;cursor:not-allowed}
</style></head>
<body>
  <h2 id="terms-heading">TripTrail demo terms</h2>
  <p>This is a fictional portal for software-testing practice. No ticket is sold, no payment is taken,
     and you must only enter synthetic passenger details.</p>
  <label><input type="checkbox" id="accept-terms" name="accept-terms"> I accept the demo terms</label>
  <p><button id="accept-button" disabled>Accept and continue</button></p>
  <script>
    var box = document.getElementById('accept-terms');
    var btn = document.getElementById('accept-button');
    box.addEventListener('change', function () { btn.disabled = !box.checked; });
    btn.addEventListener('click', function () {
      parent.postMessage({ type: 'terms-accepted' }, '*');
    });
  </script>
</body></html>`;
