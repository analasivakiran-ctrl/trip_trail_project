import type { Itinerary } from '../types';

export const CITIES = ['Hyderabad', 'Bengaluru', 'Chennai', 'Mumbai', 'Delhi'];

const make = (
  id: string, origin: string, destination: string,
  departure: string, arrival: string, price: number, seatsLeft: number
): Itinerary => ({ id, carrier: 'TripTrail Air (demo)', origin, destination, departure, arrival, price, seatsLeft });

// Fictional, fixed test data. Seeded routes: Hyderabad→Bengaluru, Hyderabad→Chennai, Mumbai→Delhi.
// Listed deliberately NOT in time order so that the sort control has something to do.
// seatsLeft = 0 means "sold out".
export const ITINERARIES: Itinerary[] = [
  make('TT101', 'Hyderabad', 'Bengaluru', '14:30', '15:55', 4890, 12),
  make('TT102', 'Hyderabad', 'Bengaluru', '06:15', '07:40', 3250, 5),
  make('TT103', 'Hyderabad', 'Bengaluru', '19:45', '21:10', 5990, 0),
  make('TT104', 'Hyderabad', 'Bengaluru', '09:00', '10:25', 2750, 20),
  make('TT105', 'Hyderabad', 'Bengaluru', '11:20', '12:45', 4150, 8),
  make('TT106', 'Hyderabad', 'Bengaluru', '22:10', '23:35', 2350, 3),

  make('TT201', 'Hyderabad', 'Chennai', '08:05', '09:20', 3100, 9),
  make('TT202', 'Hyderabad', 'Chennai', '17:40', '18:55', 3900, 0),
  make('TT203', 'Hyderabad', 'Chennai', '05:50', '07:05', 2650, 14),
  make('TT204', 'Hyderabad', 'Chennai', '13:15', '14:30', 4600, 4),
  make('TT205', 'Hyderabad', 'Chennai', '21:00', '22:15', 2900, 7),

  make('TT301', 'Mumbai', 'Delhi', '07:00', '09:10', 5200, 10),
  make('TT302', 'Mumbai', 'Delhi', '12:30', '14:40', 6400, 2),
  make('TT303', 'Mumbai', 'Delhi', '18:20', '20:30', 4800, 0),
  make('TT304', 'Mumbai', 'Delhi', '05:45', '07:55', 7200, 6),
  make('TT305', 'Mumbai', 'Delhi', '15:10', '17:20', 5600, 11),
  make('TT306', 'Mumbai', 'Delhi', '21:35', '23:45', 4300, 18),
];

export const getItineraries = (origin: string, destination: string) =>
  ITINERARIES.filter((i) => i.origin === origin && i.destination === destination);

export const toMinutes = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
};

export const durationText = (dep: string, arr: string) => {
  const diff = toMinutes(arr) - toMinutes(dep);
  return `${Math.floor(diff / 60)}h ${String(diff % 60).padStart(2, '0')}m`;
};

export const formatPrice = (n: number) => `₹${n.toLocaleString('en-IN')}`;

// Seats that are already taken on every flight (deterministic).
export const UNAVAILABLE_SEATS = ['1B', '2C', '3A', '4D', '5B', '6C'];
export const SEAT_ROWS = [1, 2, 3, 4, 5, 6];
export const SEAT_COLS = ['A', 'B', 'C', 'D'];
