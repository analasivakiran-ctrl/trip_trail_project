import { useState } from 'react';
import { Search } from 'lucide-react';
import { CITIES } from '../data/itineraries';
import type { SearchQuery } from '../types';

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const todayISO = () => new Date().toISOString().slice(0, 10);

interface Props { initial: SearchQuery | null; onSearch: (q: SearchQuery) => void }

export default function SearchForm({ initial, onSearch }: Props) {
  const [origin, setOrigin] = useState(initial?.origin ?? '');
  const [destination, setDestination] = useState(initial?.destination ?? '');
  const [date, setDate] = useState(initial?.date ?? '');
  const [error, setError] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!origin || !destination) return setError('Please choose both an origin and a destination.');
    if (origin === destination) return setError('Origin and destination must be different.');
    if (!DATE_RE.test(date) || Number.isNaN(Date.parse(date))) return setError('Enter the travel date as YYYY-MM-DD.');
    if (date < todayISO()) return setError('Travel date cannot be in the past.');
    setError('');
    onSearch({ origin, destination, date });
  };

  return (
    <form onSubmit={submit} noValidate className="glass p-6" data-testid="search-form" aria-label="Search routes">
      <h1 className="text-2xl font-semibold text-white sm:text-3xl">Find your next route</h1>
      <p className="mt-1 text-sm text-slate-300">
        Demo search on fictional flights. Seeded routes: Hyderabad→Bengaluru, Hyderabad→Chennai, Mumbai→Delhi.
      </p>
      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        <div>
          <label htmlFor="origin" className="mb-1 block text-xs text-slate-300">From</label>
          <select id="origin" name="origin" className="field" data-testid="origin-input" value={origin} onChange={(e) => setOrigin(e.target.value)}>
            <option value="">Select origin</option>
            {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="destination" className="mb-1 block text-xs text-slate-300">To</label>
          <select id="destination" name="destination" className="field" data-testid="destination-input" value={destination} onChange={(e) => setDestination(e.target.value)}>
            <option value="">Select destination</option>
            {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="travel-date" className="mb-1 block text-xs text-slate-300">Travel date</label>
          <input id="travel-date" name="travel-date" type="text" inputMode="numeric" placeholder="YYYY-MM-DD" autoComplete="off"
            className="field" data-testid="travel-date-input" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
      </div>
      {error && <p role="alert" className="err" data-testid="search-error">{error}</p>}
      <button type="submit" className="btn-primary mt-5" data-testid="search-button">
        <Search size={16} aria-hidden="true" /> Search itineraries
      </button>
    </form>
  );
}
