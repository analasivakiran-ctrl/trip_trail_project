import { useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { TERMS_HTML } from '../lib/terms';

interface Props { open: boolean; onClose: () => void; onAccept: () => void }

export default function TermsModal({ open, onClose, onAccept }: Props) {
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (!open) return;
    const onMessage = (e: MessageEvent) => {
      if (e.source === frameRef.current?.contentWindow && e.data?.type === 'terms-accepted') onAccept();
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('message', onMessage);
    window.addEventListener('keydown', onKey);
    return () => { window.removeEventListener('message', onMessage); window.removeEventListener('keydown', onKey); };
  }, [open, onAccept, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}
        >
          <motion.div
            role="dialog" aria-modal="true" aria-labelledby="terms-title" data-testid="terms-modal"
            className="glass w-full max-w-lg bg-[#19143a] p-4"
            initial={{ scale: 0.96, y: 8 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.96, y: 8 }} transition={{ duration: 0.15 }}
          >
            <div className="mb-2 flex items-center justify-between">
              <h2 id="terms-title" className="font-semibold text-white">Terms and conditions</h2>
              <button type="button" onClick={onClose} aria-label="Close terms" data-testid="terms-close" className="rounded p-1 hover:bg-white/10">
                <X size={18} aria-hidden="true" />
              </button>
            </div>
            <iframe ref={frameRef} title="Terms and conditions" id="terms-iframe" name="terms-iframe" data-testid="terms-iframe"
              srcDoc={TERMS_HTML} className="h-64 w-full rounded-lg border border-white/10 bg-[#19143a]" />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
