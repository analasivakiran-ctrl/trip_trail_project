import type { Step } from '../types';

const LABELS: { id: Step; label: string }[] = [
  { id: 'search', label: 'Search' },
  { id: 'results', label: 'Results' },
  { id: 'passenger', label: 'Passenger' },
  { id: 'seats', label: 'Seat' },
  { id: 'review', label: 'Review' },
];

export default function Stepper({ current }: { current: Step }) {
  const idx = LABELS.findIndex((s) => s.id === current);
  return (
    <ol className="mb-6 flex flex-wrap gap-2 text-xs" aria-label="Reservation progress" data-testid="stepper">
      {LABELS.map((s, i) => (
        <li
          key={s.id}
          aria-current={i === idx ? 'step' : undefined}
          data-testid={`step-${s.id}`}
          className={`rounded-full border px-3 py-1 ${
            i === idx ? 'border-[#f0d98c] bg-[#f0d98c]/15 text-[#f8f1d6]'
            : i < idx ? 'border-[#c9a227]/40 text-[#f5e6a8]' : 'border-white/10 text-slate-400'
          }`}
        >
          {i + 1}. {s.label}
        </li>
      ))}
    </ol>
  );
}
