import { ArrowLeft, ArrowRight } from 'lucide-react';
import { SEAT_COLS, SEAT_ROWS, UNAVAILABLE_SEATS } from '../data/itineraries';

interface Props { selected: string | null; onSelect: (s: string) => void; onNext: () => void; onBack: () => void }

export default function SeatMap({ selected, onSelect, onNext, onBack }: Props) {
  const seatButton = (id: string) => {
    const unavailable = UNAVAILABLE_SEATS.includes(id);
    const status = unavailable ? 'unavailable' : selected === id ? 'selected' : 'available';
    const style =
      status === 'selected' ? 'border-[#f0d98c] bg-[#f0d98c] text-slate-950'
      : status === 'unavailable' ? 'cursor-not-allowed border-white/5 bg-white/5 text-slate-600 line-through'
      : 'border-white/20 bg-white/10 text-white hover:bg-white/20';
    return (
      <button
        key={id} type="button" disabled={unavailable} onClick={() => onSelect(id)}
        className={`h-10 w-10 rounded-lg border text-xs font-medium transition ${style}`}
        data-testid="seat-option" data-seat={id} data-status={status}
        aria-label={`Seat ${id} ${status}`} aria-pressed={status === 'selected'}
      >
        {id}
      </button>
    );
  };

  return (
    <section className="glass p-6" aria-labelledby="seat-heading" data-testid="seat-section">
      <h2 id="seat-heading" className="text-xl font-semibold text-white">Choose your seat</h2>
      <div className="mt-2 flex flex-wrap gap-4 text-xs text-slate-300" aria-label="Seat legend">
        <span>⬜ Available</span><span>🟦 Selected</span><span>▫️ Unavailable</span>
      </div>

      <div className="mx-auto mt-5 w-fit space-y-2" role="group" aria-label="Seat map">
        {SEAT_ROWS.map((row) => (
          <div key={row} className="flex items-center gap-2">
            <span className="w-4 text-xs text-slate-500">{row}</span>
            {SEAT_COLS.slice(0, 2).map((c) => seatButton(`${row}${c}`))}
            <span className="w-6" aria-hidden="true" />
            {SEAT_COLS.slice(2).map((c) => seatButton(`${row}${c}`))}
          </div>
        ))}
      </div>

      <p className="mt-4 text-center text-sm text-slate-300" role="status" data-testid="seat-selected-label">
        {selected ? `Selected seat: ${selected}` : 'No seat selected yet'}
      </p>

      <div className="mt-6 flex justify-between gap-3">
        <button type="button" className="btn-ghost" onClick={onBack} data-testid="back-button">
          <ArrowLeft size={16} aria-hidden="true" /> Back
        </button>
        <button type="button" className="btn-primary" disabled={!selected} onClick={onNext} data-testid="seats-next">
          Review reservation <ArrowRight size={16} aria-hidden="true" />
        </button>
      </div>
    </section>
  );
}
