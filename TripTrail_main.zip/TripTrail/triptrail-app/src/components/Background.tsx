import { motion } from 'motion/react';

// Decorative layer: fixed, behind everything, never receives clicks.
export default function Background() {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-[#0e0b24]">
      <motion.div
        className="absolute -left-40 -top-40 h-[34rem] w-[34rem] rounded-full bg-[#5b21b6]/40 blur-[100px]"
        animate={{ x: [0, 140, 0], y: [0, 90, 0], scale: [1, 1.2, 1] }}
        transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -right-40 top-1/3 h-[38rem] w-[38rem] rounded-full bg-[#1d4ed8]/30 blur-[100px]"
        animate={{ x: [0, -160, 0], y: [0, -70, 0], scale: [1.1, 0.9, 1.1] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0e0b24]" />
    </div>
  );
}
