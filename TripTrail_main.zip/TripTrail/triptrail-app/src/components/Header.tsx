import { ExternalLink, Plane } from 'lucide-react';

export default function Header() {
  return (
    <header className="mx-auto flex max-w-5xl items-center justify-between px-4 py-5">
      <div className="flex items-center gap-2">
        <span className="rounded-xl bg-gradient-to-br from-[#c9a227] to-[#f0d98c] p-2 text-slate-950">
          <Plane size={18} aria-hidden="true" />
        </span>
        <span className="text-xl font-semibold tracking-tight text-white" data-testid="brand">TripTrail</span>
        <span className="ml-2 hidden rounded-full border border-[#f0d98c]/30 px-2 py-0.5 text-[11px] text-[#f0d98c] sm:inline">
          Demo · no real bookings
        </span>
      </div>
      {/* Opens in a NEW TAB (handout: tabs interaction) */}
      <a
        href="/help.html" target="_blank" rel="noopener noreferrer" data-testid="help-link"
        className="inline-flex items-center gap-1 text-sm text-slate-300 hover:text-white"
      >
        Help <ExternalLink size={14} aria-hidden="true" />
      </a>
    </header>
  );
}
