import { ArrowLeft, RotateCcw } from 'lucide-react';
import { formatPrice } from '../data/itineraries';
import type { Itinerary, Passenger, SearchQuery } from '../types';

interface Props {
  itinerary: Itinerary; query: SearchQuery; passenger: Passenger; seat: string;
  onBack: () => void; onReset: () => void;
}

// Final step of the workflow. NO payment and NO "confirmed" status – the handout says to stop at review.
export default function ReviewSummary({ itinerary, query, passenger, seat, onBack, onReset }: Props) {
  const rows: [string, string, string][] = [
    ['Route', `${itinerary.origin} → ${itinerary.destination}`, 'review-route'],
    ['Date', query.date, 'review-date'],
    ['Departure / arrival', `${itinerary.departure} / ${itinerary.arrival}`, 'review-times'],
    ['Passenger', `${passenger.firstName} ${passenger.surname}`, 'review-passenger'],
    ['Email', passenger.email, 'review-email'],
    ['Seat', seat, 'review-seat'],
    ['Fare', formatPrice(itinerary.price), 'review-fare'],
    ['Status', 'Simulated review only – nothing purchased', 'review-status'],
  ];
  return (
    <section className="glass p-6" aria-labelledby="review-heading" data-testid="reservation-review">
      <h2 id="review-heading" className="text-xl font-semibold text-white">Reservation review</h2>
      <p className="mt-1 text-sm text-slate-300">Demo only. No ticket is issued and no payment is taken.</p>
      <table className="mt-4 w-full text-left text-sm" data-testid="review-table">
        <caption className="sr-only">Reservation summary</caption>
        <tbody>
          {rows.map(([label, value, id]) => (
            <tr key={id} className="border-t border-white/10">
              <th scope="row" className="w-2/5 py-2 pr-3 font-normal text-slate-400">{label}</th>
              <td className="py-2 text-white" data-testid={id}>{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-6 flex justify-between gap-3">
        <button type="button" className="btn-ghost" onClick={onBack} data-testid="back-button">
          <ArrowLeft size={16} aria-hidden="true" /> Back
        </button>
        <button type="button" className="btn-primary" onClick={onReset} data-testid="new-search-button">
          <RotateCcw size={16} aria-hidden="true" /> Start a new search
        </button>
      </div>
    </section>
  );
}
