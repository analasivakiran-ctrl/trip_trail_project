import { formatPrice } from '../data/itineraries';
import type { Itinerary, SearchQuery } from '../types';

// Small recap of the chosen itinerary; shown on the passenger and seat pages (TC04).
export default function ItineraryBanner({ itinerary, query }: { itinerary: Itinerary; query: SearchQuery }) {
  return (
    <div className="glass mb-4 flex flex-wrap items-center justify-between gap-3 p-4" data-testid="selected-itinerary-summary">
      <div>
        <p className="text-xs text-slate-400">Selected itinerary {itinerary.id}</p>
        <p className="font-semibold text-white" data-testid="summary-route">{itinerary.origin} → {itinerary.destination}</p>
        <p className="text-sm text-slate-300">
          <span data-testid="summary-date">{query.date}</span> · {itinerary.departure}–{itinerary.arrival}
        </p>
      </div>
      <p className="text-xl font-semibold text-[#f0d98c]" data-testid="summary-fare">{formatPrice(itinerary.price)}</p>
    </div>
  );
}
