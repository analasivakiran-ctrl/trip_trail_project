import { useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, FileText } from 'lucide-react';
import type { Passenger } from '../types';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
type Errors = Partial<Record<keyof Passenger, string>>;

interface Props {
  initial: Passenger | null;
  termsAccepted: boolean;
  onOpenTerms: () => void;
  onSubmit: (p: Passenger) => void;
  onBack: () => void;
}

export default function PassengerForm({ initial, termsAccepted, onOpenTerms, onSubmit, onBack }: Props) {
  const [form, setForm] = useState<Passenger>(initial ?? { firstName: '', surname: '', email: '', nationality: '' });
  const [errors, setErrors] = useState<Errors>({});
  const set = (k: keyof Passenger) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const err: Errors = {};
    if (!form.firstName.trim()) err.firstName = 'First name is required.';
    if (!form.surname.trim()) err.surname = 'Surname is required.';
    if (!EMAIL_RE.test(form.email)) err.email = 'Enter a valid (synthetic) email address.';
    if (!form.nationality) err.nationality = 'Please choose a nationality.';
    setErrors(err);
    if (Object.keys(err).length === 0) onSubmit(form); // workflow only advances when valid
  };

  return (
    <form onSubmit={submit} noValidate className="glass p-6" data-testid="passenger-form" aria-label="Passenger details">
      <h2 className="text-xl font-semibold text-white">Passenger details</h2>
      <p className="mt-1 text-sm text-amber-200/90">Use synthetic test data only – never real personal information.</p>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="first-name" className="mb-1 block text-xs text-slate-300">First name</label>
          <input id="first-name" name="first-name" className="field" data-testid="passenger-first-name" value={form.firstName} onChange={set('firstName')} aria-invalid={!!errors.firstName} />
          {errors.firstName && <p role="alert" className="err" data-testid="error-first-name">{errors.firstName}</p>}
        </div>
        <div>
          <label htmlFor="surname" className="mb-1 block text-xs text-slate-300">Surname</label>
          <input id="surname" name="surname" className="field" data-testid="passenger-surname" value={form.surname} onChange={set('surname')} aria-invalid={!!errors.surname} />
          {errors.surname && <p role="alert" className="err" data-testid="error-surname">{errors.surname}</p>}
        </div>
        <div>
          <label htmlFor="email" className="mb-1 block text-xs text-slate-300">Email (synthetic)</label>
          <input id="email" name="email" type="email" className="field" data-testid="passenger-email" value={form.email} onChange={set('email')} aria-invalid={!!errors.email} />
          {errors.email && <p role="alert" className="err" data-testid="error-email">{errors.email}</p>}
        </div>
        <div>
          <label htmlFor="nationality" className="mb-1 block text-xs text-slate-300">Nationality</label>
          <select id="nationality" name="nationality" className="field" data-testid="passenger-nationality" value={form.nationality} onChange={set('nationality')}>
            <option value="">Select</option>
            <option value="Indian">Indian</option>
            <option value="Other">Other (demo)</option>
          </select>
          {errors.nationality && <p role="alert" className="err" data-testid="error-nationality">{errors.nationality}</p>}
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button type="button" className="btn-ghost" onClick={onOpenTerms} data-testid="open-terms-button">
          <FileText size={16} aria-hidden="true" /> Read terms
        </button>
        <span data-testid="terms-status" data-accepted={String(termsAccepted)}
          className={`inline-flex items-center gap-1 text-sm ${termsAccepted ? 'text-[#f5e6a8]' : 'text-slate-400'}`}>
          {termsAccepted && <CheckCircle2 size={16} aria-hidden="true" />}
          {termsAccepted ? 'Terms accepted' : 'Terms not accepted'}
        </span>
      </div>

      <div className="mt-6 flex justify-between gap-3">
        <button type="button" className="btn-ghost" onClick={onBack} data-testid="back-button">
          <ArrowLeft size={16} aria-hidden="true" /> Back
        </button>
        <button type="submit" className="btn-primary" disabled={!termsAccepted} data-testid="passenger-next">
          Continue to seats <ArrowRight size={16} aria-hidden="true" />
        </button>
      </div>
    </form>
  );
}
