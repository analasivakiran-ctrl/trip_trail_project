import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Ban, Clock } from 'lucide-react';
import { durationText, formatPrice, getItineraries } from '../data/itineraries';
import type { Itinerary, SearchQuery } from '../types';

type Sort = 'none' | 'asc' | 'desc';
interface Props { query: SearchQuery; onSelect: (i: Itinerary) => void; onBack: () => void }

export default function ResultsList({ query, onSelect, onBack }: Props) {
  const [maxPrice, setMaxPrice] = useState('');
  const [sort, setSort] = useState<Sort>('none');

  const all = useMemo(() => getItineraries(query.origin, query.destination), [query]);
  const visible = useMemo(() => {
    let r = maxPrice ? all.filter((i) => i.price <= Number(maxPrice)) : [...all];
    if (sort === 'asc') r = r.sort((a, b) => a.departure.localeCompare(b.departure));
    if (sort === 'desc') r = r.sort((a, b) => b.departure.localeCompare(a.departure));
    return r;
  }, [all, maxPrice, sort]);

  return (
    <section aria-labelledby="results-heading" data-testid="results-section">
      <button type="button" className="btn-ghost mb-4" onClick={onBack} data-testid="back-button">
        <ArrowLeft size={16} aria-hidden="true" /> Modify search
      </button>
      <div className="glass p-5">
        <h2 id="results-heading" className="text-xl font-semibold text-white" data-testid="results-heading">
          {query.origin} → {query.destination}
        </h2>
        <p className="text-sm text-slate-300" data-testid="results-date">{query.date}</p>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="price-filter" className="mb-1 block text-xs text-slate-300">Maximum price</label>
            <select id="price-filter" className="field" data-testid="price-filter" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)}>
              <option value="">Any price</option>
              <option value="3000">Up to ₹3,000</option>
              <option value="4500">Up to ₹4,500</option>
              <option value="6000">Up to ₹6,000</option>
            </select>
          </div>
          <div>
            <label htmlFor="departure-sort" className="mb-1 block text-xs text-slate-300">Sort by departure</label>
            <select id="departure-sort" className="field" data-testid="departure-sort" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
              <option value="none">Default order</option>
              <option value="asc">Earliest first</option>
              <option value="desc">Latest first</option>
            </select>
          </div>
        </div>
        <p className="mt-4 text-sm text-slate-300" role="status" data-testid="results-count">
          {visible.length} {visible.length === 1 ? 'itinerary' : 'itineraries'} found
        </p>
      </div>

      {visible.length === 0 ? (
        <p className="glass mt-4 p-6 text-center text-slate-300" data-testid="no-results">
          No itineraries match. Try another route (seeded: Hyderabad→Bengaluru, Hyderabad→Chennai, Mumbai→Delhi) or a higher price limit.
        </p>
      ) : (
        <ul className="mt-4 space-y-3" data-testid="results-list">
          {visible.map((it, n) => {
            const soldOut = it.seatsLeft === 0;
            return (
              // Entrance-only animation (no exit) so old cards never linger in the DOM during tests.
              <motion.li
                key={it.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: Math.min(n * 0.04, 0.3) }}
                className={`glass flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between ${soldOut ? 'opacity-80' : ''}`}
                data-testid="itinerary-card"
                data-itinerary-id={it.id}
                data-price={it.price}
                data-departure={it.departure}
                data-available={String(!soldOut)}
              >
                <div>
                  <p className="text-xs text-slate-400">{it.carrier} · {it.id}</p>
                  <p className="mt-1 text-lg font-semibold text-white">
                    <span data-testid="departure-time">{it.departure}</span> → <span data-testid="arrival-time">{it.arrival}</span>
                  </p>
                  <p className="flex items-center gap-1 text-sm text-slate-300">
                    <Clock size={14} aria-hidden="true" /> <span data-testid="duration">{durationText(it.departure, it.arrival)}</span>
                  </p>
                </div>
                <div className="flex items-center gap-4 sm:flex-col sm:items-end">
                  <p className="text-xl font-semibold text-[#f0d98c]" data-testid="price">{formatPrice(it.price)}</p>
                  <p className={`text-sm ${soldOut ? 'text-rose-300' : 'text-[#f5e6a8]'}`} data-testid="availability-text">
                    {soldOut ? 'Sold out' : `${it.seatsLeft} seats left`}
                  </p>
                </div>
                <button
                  type="button" className="btn-primary" data-testid="select-itinerary"
                  disabled={soldOut} aria-label={`Select itinerary ${it.id}`} onClick={() => onSelect(it)}
                >
                  {soldOut ? (<><Ban size={16} aria-hidden="true" /> Unavailable</>) : 'Select'}
                </button>
              </motion.li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
